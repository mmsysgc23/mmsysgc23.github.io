// Copyright (c) 2023. ByteDance Inc. All rights reserved.

#pragma once

#include "demo/utils/thirdparty/quiche/rtt_stats.h"
using RttStats = quic::RttStats;
