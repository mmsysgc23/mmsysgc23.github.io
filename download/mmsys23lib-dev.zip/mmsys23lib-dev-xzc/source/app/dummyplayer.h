// Copyright (c) 2023. ByteDance Inc. All rights reserved.

#pragma once

#include <utility>
#include <spdlog/spdlog.h>
#include "playtaskinfo.h"
#include "basefw/base/timer.h"
#include "basefw/base/log.h"
#include "common/p2phandlerdef.h"
#include "common/p2pmgrcomm.h"
#include "DummyDownloadMgr.hpp"
#include "spdlog/spdlog.h"


class PlayController;
class DummyDownloaderHandler;

/** A dummy player implementation, mimicking the application layer
 * The file offset will try to move forward 1/10 * byte-rate in every 100ms,
 * if failed, a play stuck event will be recorded
**/
class DummyPlayer : public DummyDownloaderHandler,
                    public DummyPlayerHandler,
                    public basefw::enable_shared_from_this<DummyPlayer>
{
public:

    DummyPlayer() = default;

    void DummyPlayerInit(std::shared_ptr<boost::asio::io_service> ioServicePool);

    virtual ~DummyPlayer();

    void GetPlayTaskInfo(PlayTaskInfo& playTaskInfo) override;

    void StartPlayer();

    void StopPlayer();

    void SetTransportModuleSettings(std::shared_ptr<TransportModuleSettings> transMd);

    void OnTimer(int times);

    /////////////////////////////Add Up peer info
    void AddUpPeers(std::vector<UpPeerInfo> upnodes);

    /////////////////////////P2PDlHandler///////////////

    /** Download task asking for more task
     * */
    void DlGetdownloadpiece(fw::ID& rid, int32_t maxcnt) override;

    /** Transport layer forward downloaded data to player
     * */
    void DlP2PData(fw::ID& rid, int32_t pieceno, fw::IOBuffer& buf, uint64_t tickcnt) override;

    void DoDownloadNow();

    void StartDownloadTask(uint32_t ip, uint16_t port, basefw::ID myPeerID);


    //we just use this fuction to fill up the playing queue,not sure what else it can do...
    void CalcDlPieces(int64_t rpos, int64_t epos, std::set<int32_t>& pieces);

    /** Force timer will stop the whole player if due to any reason,
     * the download task didn't finish at a long time
     * */
    void OnForceStopTimer(int times);

private:
    bool m_bruning = false;
    std::shared_ptr<boost::asio::io_context> m_ioService;
    std::shared_ptr<basefw::AsyncWaitTimer> playertimer;

    std::shared_ptr<DummyDownloadMgr> m_p2pmgrptr;

    std::shared_ptr<basefw::FileBmp> m_filebmp;

    /////////////////////////////////
    std::shared_ptr<PlayController> playController;
    std::map<int32_t, basefw::IOBuffer> m_mapPieceNoToPieceDat;
    std::set<int32_t> m_playpieces;
    std::set<int32_t> m_downloadingpieces;
    basefw::ID m_rid;

};



