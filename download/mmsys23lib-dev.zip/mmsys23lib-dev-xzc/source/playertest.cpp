// Copyright (c) 2023. ByteDance Inc. All rights reserved.

#include <memory>
#include <spdlog/sinks/stdout_color_sinks.h>
#include <spdlog/sinks/basic_file_sink.h>
#include <fstream>

#include "app/dummyplayer.h"
#include "spdlog/spdlog.h"
#include "configjson.hpp"
#include "download/transportcontroller/demo/demotransportcontroller.hpp"

using json = nlohmann::json;

/// This demo executable file shows how to register user defined transport module and start the dummy player
int main(int argc, char** argv)
{

    ///////////////  import upside nodes from a json file ///////////////
    if (argc != 2)
    {
        std::cerr << " Need Json file" << std::endl;
        return -1;
    }
    // parse initiate parameters
    std::string jsonpath(argv[1]);
    std::cout << "Json file :" << jsonpath << std::endl;
    DownNodeConfig downNodeConfig;
    try
    {
        std::ifstream i(jsonpath);
        json j;
        i >> j;
        from_json(j, downNodeConfig);
        std::cout << std::setw(4) << j << std::endl;
    }
    catch (std::exception& e)
    {
        std::cerr << "Parse Json failed with exception " << e.what() << std::endl;
    }

    ///////////////Set loggers///////////////
    // check spdlog's manuel for more detail
    std::vector<spdlog::sink_ptr> sinks;
    sinks.push_back(std::make_shared<spdlog::sinks::stdout_color_sink_mt>());
    sinks.push_back(std::make_shared<spdlog::sinks::basic_file_sink_mt>("logfile.txt", true));
    auto combined_logger = std::make_shared<spdlog::logger>("", begin(sinks), end(sinks));
    spdlog::set_default_logger(combined_logger);
    spdlog::set_level(spdlog::level::trace);


    ///////////////Create a Transport Module Setting///////////////
    std::shared_ptr<TransportModuleSettings> myTransportModuleSettings = std::make_shared<TransportModuleSettings>();

    // create your TransportCtlConfig class here. The parameters inside this class will be passed to
    // your TransportController.

    std::shared_ptr<DemoTransportCtlConfig> myTransportCtlConfig = std::make_shared<DemoTransportCtlConfig>();
    // these values will be passed to demo transport module
    myTransportCtlConfig->minWnd = 32;
    myTransportCtlConfig->maxWnd = 64;

    // Create your TransportCtlFactory
    std::shared_ptr<DemoTransportCtlFactory> myTransportFactory = std::make_shared<DemoTransportCtlFactory>();

    // assemble transport controller config and transport controller factory together
    myTransportModuleSettings->transportCtlConfig = myTransportCtlConfig;
    myTransportModuleSettings->transportCtlFactory = myTransportFactory;


    ///////////////Create Player///////////////
    std::shared_ptr<DummyPlayer> dummPlayer = std::make_shared<DummyPlayer>();

    ///////////////Add up side nodes///////////////
    std::vector<UpPeerInfo> upnodes;
    for (auto& upnodeconfig: downNodeConfig.upnodes)
    {
        basefw::ID upID(upnodeconfig.selfpeerID);
        uint32_t upip = basefw::StringToIp(upnodeconfig.IP);
        uint16_t upport = upnodeconfig.port;
        upnodes.emplace_back(UpPeerInfo{ upID, upip, upport });
    }
    dummPlayer->AddUpPeers(upnodes);

    ///////////////Register your transport module into Player///////////////
    dummPlayer->SetTransportModuleSettings(myTransportModuleSettings);

    // create a boost::asio io context for play operation
    auto iocontext = std::make_shared<boost::asio::io_context>();
    auto work_guard = boost::asio::make_work_guard(*iocontext);

    // init and start player
    dummPlayer->DummyPlayerInit(iocontext);
    dummPlayer->StartPlayer();

    // create a timer, we will start download after 10s
    boost::asio::steady_timer t(*iocontext, boost::asio::chrono::seconds(10));

    //set download task, wait for 10 seconds
    t.async_wait([&](const boost::system::error_code& ec)
    {
        if (ec)
        {
            spdlog::info(ec.message());
        }
        spdlog::info("====StartDownload in 10 seconds============ ");
        dummPlayer->StartDownloadTask();
    });

    // start the play thread
    iocontext->run();
    return 0;
}
