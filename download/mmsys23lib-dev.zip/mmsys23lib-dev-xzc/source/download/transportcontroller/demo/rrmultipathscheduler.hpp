// Copyright (c) 2023. ByteDance Inc. All rights reserved.

#pragma once


#include <vector>
#include <set>
#include "multipathschedulerI.h"

class RRMultiPathScheduler : public MultiPathSchedulerAlgo
{
    MultiPathSchedulerType SchedulerType() override
    {
        return MultiPathSchedulerType::MULTI_PATH_SCHEDULE_RR;
    }

    RRMultiPathScheduler(const fw::ID& rid, std::map<fw::ID, fw::shared_ptr<SessionStreamController>>& dlsessionmap,
            std::multimap<int32_t, fw::shared_ptr<SessionStreamController>>& sortmmap,
            std::set<int32_t>& needdownloadpiece,
            std::set<int32_t>& needdownloadsubpiece)
            : MultiPathSchedulerAlgo(rid, dlsessionmap, sortmmap, needdownloadpiece, needdownloadsubpiece)
    {

    }

    ~RRMultiPathScheduler() override
    {

    }

    int32_t StartMultiPathScheduler(fw::weak_ptr<MultiPathSchedulerHandler> mpsHandler)
    {

    }

    bool StopMultiPathScheduler()
    {

    }

    void OnSessionCreate(const fw::ID& sessionid)
    {
        auto&& sessionItor = m_dlsessionmap.find(sessionid);
        if (sessionItor == m_dlsessionmap.end())
        {
            m_dlsessionmap[sessionid] = std::make_shared<SessionStreamController>();
        }
        else
        {

        }

    }

    void OnSessionDestory(const fw::ID& sessionid)
    {


    }

    void OnResetDownload() override
    {
        for (auto&& sessionItor: m_dlsessionmap)
        {
//            m_dlsessionmap
        }

    }

    void DoMultiPathSchedule() override
    {
        // sort session first
        SortSession(m_sortmmap);
        // send pkt requests on each session based on ascend order;
        FillUpSessionTask();

    }


    uint32_t DoSinglePathSchedule(const fw::ID& sessionid) override
    {

    }

    void OnTimedOut(const fw::ID& sessionid, std::vector<int32_t>& spns) override
    {
        for (auto& spidx: spns)
        {
            auto&& rt = LostPieces.emplace(spidx);
            if (!rt.second)
            {
                // warn already lost
            }
        }
    }

    void OnReceiveSubpieceData(const fw::ID& sessionid, uint32_t seq, int32_t spno) override
    {
        auto&& sessionItor = m_dlsessionmap.find(sessionid);
        if (sessionItor != m_dlsessionmap.end())
        {
            sessionItor->second->OnDataPktReceived(seq, spno);
        }
        else
        {
            //warn: received on an unknown session
        }
    }

    void SortSession(std::multimap<int32_t, fw::shared_ptr<SessionStreamController>>& sortmmap) override
    {
        sortmmap.clear();
        for (auto&& sessionItor: m_dlsessionmap)
        {
            auto score = sessionItor.second->GetRtt();
            sortmmap.emplace(score, sessionItor.second);
        }

    }

    int32_t DoSendSessionSubTask(const fw::ID& sessionid) override
    {
        int32_t i32Result = -1;
        auto& setNeedDlSubpiece = session_needdownloadsubpiece[sessionid];
        if (setNeedDlSubpiece.empty())
        {
            return i32Result;
        }
        std::vector<int32_t> vecSubpieces;
        for (auto itor = setNeedDlSubpiece.begin(); itor != setNeedDlSubpiece.end(); ++itor)
        {
            vecSubpieces.emplace_back(*itor);
        }

        fw::shared_ptr<MultiPathSchedulerHandler> ph = m_phandler.lock();
        if (ph)
        {
            ph->DoSendDataPieceRequest(sessionid, vecSubpieces);
        }

        return i32Result;
    }

private:

    void FillUpSessionTask()
    {
        // 1. put lost packets back into main download queue
        // 2. go through every session,find how many pieces we can request at one time
        // 3. try to request enough piece cnt from up layer, if necessary
        // 4. fill up each session Queue, based on min RTT first order, and send


    }


    std::set<int32_t> LostPieces;// the lost pieces queue, waiting to be retransmitted

    std::map<fw::ID, std::set<int32_t>> session_needdownloadsubpiece;// session task queues

    fw::weak_ptr<MultiPathSchedulerHandler> m_phandler;


};

