
/** Copyright 2014 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.
*/
// Copyright (c) 2023. ByteDance Inc. All rights reserved.

#pragma once

#include <cstdint>
/** RTT Sampler Modified from Chromium Quic implementation*/
// A convenience class to store rtt samples and calculate smoothed rtt.
class RttStats
{
public:
    // Calculates running standard-deviation using Welford's algorithm:
    // https://en.wikipedia.org/wiki/Algorithms_for_calculating_variance#
    // Welford's_Online_algorithm.
    struct StandardDeviationCaculator
    {
        StandardDeviationCaculator()
        {
        }

        // Called when a new RTT sample is available.
        void OnNewRttSample(uint64_t rtt_sample,
                uint64_t smoothed_rtt);

        // Calculates the standard deviation.
        uint64_t CalculateStandardDeviation() const;

        bool has_valid_standard_deviation = false;

    private:
        double m2 = 0;
    };

    RttStats();

    RttStats(const RttStats&) = delete;

    RttStats& operator=(const RttStats&) = delete;

    // Updates the RTT from an incoming ack which is received |send_delta| after
    // the packet is sent and the peer reports the ack being delayed |ack_delay|.
    // Returns true if RTT was updated, and false if the sample was ignored.
    bool UpdateRtt(int64_t send_delta, int64_t ack_delay,
            int64_t now);

    // Causes the smoothed_rtt to be increased to the latest_rtt if the latest_rtt
    // is larger. The mean deviation is increased to the most recent deviation if
    // it's larger.
    void ExpireSmoothedMetrics();

    // Called when connection migrates and rtt measurement needs to be reset.
    void OnConnectionMigration();

    // Returns the EWMA smoothed RTT for the connection.
    // May return Zero if no valid updates have occurred.
    int64_t smoothed_rtt() const
    {
        return smoothed_rtt_;
    }

    // Returns the EWMA smoothed RTT prior to the most recent RTT sample.
    int64_t previous_srtt() const
    {
        return previous_srtt_;
    }

    int64_t initial_rtt() const
    {
        return initial_rtt_;
    }

    int64_t SmoothedOrInitialRtt() const
    {
        return smoothed_rtt_ == 0 ? initial_rtt_ : smoothed_rtt_;
    }

    int64_t MinOrInitialRtt() const
    {
        return min_rtt_ == 0 ? initial_rtt_ : min_rtt_;
    }

    // Sets an initial RTT to be used for SmoothedRtt before any RTT updates.
    void set_initial_rtt(int64_t initial_rtt)
    {
        if (initial_rtt == 0)
        {
//                QUIC_BUG(quic_bug_10453_1) << "Attempt to set initial rtt to <= 0.";
            return;
        }
        initial_rtt_ = initial_rtt;
    }

    // The most recent rtt measurement.
    // May return Zero if no valid updates have occurred.
    int64_t latest_rtt() const
    {
        return latest_rtt_;
    }

    // Returns the min_rtt for the entire connection.
    // May return Zero if no valid updates have occurred.
    int64_t min_rtt() const
    {
        return min_rtt_;
    }

    int64_t mean_deviation() const
    {
        return mean_deviation_;
    }

    // Returns standard deviation if there is a valid one. Otherwise, returns
    // mean_deviation_.
    int64_t GetStandardOrMeanDeviation() const;

    int64_t last_update_time() const
    {
        return last_update_time_;
    }

    void EnableStandardDeviationCalculation()
    {
        calculate_standard_deviation_ = true;
    }

    void CloneFrom(const RttStats& stats);

private:

    int64_t latest_rtt_;
    int64_t min_rtt_;
    int64_t smoothed_rtt_;
    int64_t previous_srtt_;
    // Mean RTT deviation during this session.
    // Approximation of standard deviation, the error is roughly 1.25 times
    // larger than the standard deviation, for a normally distributed signal.
    int64_t mean_deviation_;
    // Standard deviation calculator. Only used calculate_standard_deviation_ is
    // true.
    StandardDeviationCaculator standard_deviation_calculator_;
    bool calculate_standard_deviation_;
    int64_t initial_rtt_;
    int64_t last_update_time_;
};
