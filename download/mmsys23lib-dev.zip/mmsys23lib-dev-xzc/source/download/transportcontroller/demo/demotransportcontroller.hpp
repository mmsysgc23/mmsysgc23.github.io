// Copyright (c) 2023. ByteDance Inc. All rights reserved.


#pragma once

#include "download/transportcontroller/transportcontroller.hpp"
#include "multipathschedulerI.h"
#include "congestioncontrol.hpp"
#include "sessionstreamcontroller.hpp"
#include "rrmultipathscheduler.hpp"



struct DemoTransportCtlConfig : public TransPortControllerConfig
{
    uint32_t pieceByteSize{1024};
    uint32_t maxWnd{64};
    uint32_t minWnd{1};
    uint32_t slowStartThreshold{32};
};

/** @class A demo TransportController used to create DemoTransportCtl
 * */
class DemoTransportCtlFactory : public TransportControllerFactory
{
public:
    ~ DemoTransportCtlFactory() override = default;

    std::unique_ptr<P2PTransportController> MakeTransportController(TransPortControllerConfig ctlConfig) override
    {
        std::unique_ptr<P2PTransportController> transportControllerImpl(new DemoTransportCtl(ctlConfig));
        return transportControllerImpl;
    }
};

/** @brief a demo transport algorithm class implementing the P2PTransportController interface
 * */
class DemoTransportCtl : public P2PTransportController,
                         public MultiPathSchedulerHandler,
                         public SessionStreamCtlHandler,
                         public std::enable_shared_from_this<DemoTransportCtl>
{
public:

    explicit DemoTransportCtl(TransPortControllerConfig ctlConfig)
    : P2PTransportController(ctlConfig)
    {
        //multipathscheduler = std::make_shared(RRMultiPathScheduler());
    }

    ~ DemoTransportCtl() override = default;;

    /** @brief The Controller is started
     *  @param tansDlTkInfo  download task info
     *  @param transCtlHandler application layer callback
     **/
    bool StartTransportController(TransportDownloadTaskInfo tansDlTkInfo,
            std::weak_ptr<P2PTransCtlHandler> transCtlHandler) override
    {
        if (isRunning)
        {
            //warn: already started
            return true;
        }
        else
        {
            isRunning = true;
            return true;
        }
        multipathscheduler->StartMultiPathScheduler(shared_from_this());
        return true;
    }

    /** @brief The controller should be fully stopped and prepare to be destructed.
     * */
    void StopTransportController() override
    {
        multipathscheduler->StopMultiPathScheduler();
    }

    /**
     * @brief Session is ready to send data request
     * @param sessionid
     */
    void OnSessionCreate(const fw::ID& sessionid) override
    {
        auto&& sessionItor= sessStreamCtlMap.find(sessionid);
        if (sessionItor==sessStreamCtlMap.end())
        {
            sessStreamCtlMap[sessionid] = std::make_shared<SessionStreamController>();
        }
        else
        {
            // session recreate again

        }
        // forward the message
        multipathscheduler->OnSessionCreate(sessionid);
    }

    /**
     * @brief Session is no longer available
     * @param sessionid
     */
    void OnSessionDestory(const fw::ID& sessionid) override
    {
        // forward the message First
        multipathscheduler->OnSessionDestory(sessionid);
        // do clean jobs
        auto&& sessionItor= sessStreamCtlMap.find(sessionid);
        if (sessionItor==sessStreamCtlMap.end())
        {
            // warn: try to destroy a session we don't know
        }
        else
        {
            sessStreamCtlMap[sessionid]->StopSessionStreamCtl();
            sessStreamCtlMap[sessionid].reset();
        }

    }

    /**
     * @brief The application layer is adding tasks to transport layer.
     * @param datapiecesVec the piece numbers to be added
     */
    void OnPieceTaskAdding(std::vector<int32_t>& datapiecesVec) override
    {
        for (auto&&dataPiece:datapiecesVec)
        {
            auto rt=downloadPieces.emplace(dataPiece);
            if (!rt.second)
            {
                // warning: already has
            }
        }
        // Do multipath schedule after new tasks added
        multipathscheduler->DoMultiPathSchedule();
    }

    /**@brief the download task is started now.
     * */
    void OnDownloadTaskStart() override
    {
        if (isRunning)
        {
            if (multipathscheduler)
            {
                multipathscheduler->StartMultiPathScheduler(shared_from_this());
            }
        }

    }

    /**@brief the download task is stopped and this object may be destroyed at any time.
     * */
    void OnDownloadTaskStop() override
    {

    }

    /**@brief the download task has been reset, the task will be stopped soon.
     * */
    void OnDownloadTaskReset() override
    {

    }

    /** @brief Some data pieces have been received on session with sessionid
     * @param sessionid  the session
     * @param datapiece data pieces number, each packet carry exact one 1KB data piece
     * */
    void OnDataPiecesReceived(const fw::ID& sessionid, uint32_t seq, int32_t datapiece) override
    {
        multipathscheduler->OnReceiveSubpieceData(sessionid,seq,datapiece);
    }

    /**
     * @brief Signal that when a data request packet has been sent successfully
     * @note When we say SENT, it means the packet has been given to ASIO to sent. The packet itself may still inside OS
     * kernel space or hardware buffer.
     * @param sessionid remote upside session id
     * @param datapieces the data piece number, each packet may carry 1 piece or 8 pieces
     * @param senttime_ms the sent timepoint in ms
     */
    void OnDataSent(const fw::ID& sessionid, std::vector<int32_t>& datapieces, uint32_t seq, uint64_t senttime_ms)override
    {
        auto&& sessStreamItor = sessStreamCtlMap.find(sessionid);
        if (sessStreamItor!= sessStreamCtlMap.end())
        {
            sessStreamItor->second->OnDataRequestPktSent();
        }
    }

    /**@brief Check timeout events periodically, the user defined timeout check operation may be called in here.
     * */
    void OnLossDetectionAlarm() override
    {
        // Step 1: Check loss in each session
        for (auto&& sessStreamItor: sessStreamCtlMap)
        {
            sessStreamItor.second->OnLossDetectionAlarm();
        }
        // Step 2: Forward message to Multipath Scheduler
        multipathscheduler->DoMultiPathSchedule();
    }

    // session stream handler

    void OnPiecePktTimeout(const basefw::ID& peerid, const std::vector<int32_t>& spns)override
    {
        if (!isRunning)
        {
            return ;
        }

        multipathscheduler->OnTimedOut(peerid,spns);

    }


private:

    bool isRunning{false};

    std::unique_ptr<MultiPathSchedulerAlgo> multipathscheduler;

    std::set<int32_t> downloadPieces;
    std::set<int32_t> inflightPieces;
    std::map<basefw::ID,std::set<int32_t>> sessionDownloadPieces;
    std::map<basefw::ID,std::shared_ptr<SessionStreamController>> sessStreamCtlMap;
};
