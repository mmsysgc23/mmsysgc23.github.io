// Copyright (c) 2023. ByteDance Inc. All rights reserved.


#pragma once

#include <cstdint>
#include <chrono>
#include "../utils/thirdparty/quiche/rtt_stats.hpp"

enum class CongestionCtlType : uint8_t
{
    none = 0,
    reno = 1
};

struct SeqDataIdPair
{
    uint32_t seq{ 0 };/**sequence number*/
    int32_t dataPieceId{ -1 };/**The ID of this received piece */
};
struct LossEvent
{
    bool valid{ false };
    // There may be multiple timeout events at one time
    std::vector<SeqDataIdPair> lossPackets;
    uint64_t timePoint{ 0 };
};

struct AckEvent
{
    bool valid{ false };
    uint32_t seqNum{ 0 };/**sequence number*/
    int32_t dataPieceId{ -1 };/** The ID of this received piece*/
    uint64_t timePoint{ 0 };/** since we receive packets one by one, each packet carries only one data piece*/
};
typedef uint64_t Timepoint;
typedef std::chrono::microseconds RttType;
struct DownloadingPacket
{
    uint32_t seqNum{ 0 };/**sequence number*/
    int32_t dataPieceId{ -1 };/** The ID of this received piece*/
    Timepoint sendtic{ 0 };
    bool IsReTran{ false };
};

class LossDetectionAlgo
{

public:
    virtual void DetectLoss(const std::deque<DownloadingPacket>& downloading, Timepoint eventtime,
            AckEvent ackEvent, uint64_t maxacked, LossEvent& losses, RttStats& rttStats)
    {
    };

    virtual ~LossDetectionAlgo() = default;

};

class DefaultLossDetectionAlgo : public LossDetectionAlgo
{
public:
    void DetectLoss(const std::deque<DownloadingPacket>& downloading, Timepoint eventtime, AckEvent ackEvent,
            uint64_t maxacked, LossEvent& losses, RttStats& rttStats) override
    {
        /** RFC 9002 Section 6
         * */
        uint64_t maxrtt = std::max(rttStats.previous_srtt(), rttStats.latest_rtt());
        uint64_t loss_delay = maxrtt + (maxrtt * 5 / 4);
        loss_delay = std::max(loss_delay, (uint64_t)1);
        for (auto&& pkt: downloading)
        {
            if (Timepoint(pkt.sendtic + loss_delay) >= eventtime)
            {
                SeqDataIdPair lostpkt;
                lostpkt.seq = pkt.seqNum;
                lostpkt.dataPieceId = pkt.dataPieceId;
                losses.lossPackets.emplace_back(lostpkt);
            }
        }
        if (!losses.lossPackets.empty())
        {
            losses.timePoint = eventtime;
        }

    }

private:
};


class CongestionCtlAlgo
{
public:
    ////
    virtual CongestionCtlType GetCCtype() = 0;

    virtual ~CongestionCtlAlgo() = default;

    /////  Event
    virtual void OnDataSent(SeqDataIdPair dataPacket) = 0;

    virtual void OnDataAckOrLoss(const AckEvent& ackEvent, const LossEvent& lossEvent) = 0;

    /////
    virtual uint32_t GetCWND() = 0;

//    virtual uint32_t GetFreeCWND() = 0;

};


class RenoCongestionContrl : public CongestionCtlAlgo
{
public:
    void OnDataSent(SeqDataIdPair dataPacket) override
    {

    }

    void OnDataAckOrLoss(const AckEvent& ackEvent, const LossEvent& lossEvent) override
    {

        if (lossEvent.valid)
        {
            OnDataLoss(lossEvent);
        }

        if (ackEvent.valid)
        {
            OnDataRecv(ackEvent);
        }

    }

    /////
    uint32_t GetCWND() override
    {
        return cwnd;
    }

//    virtual uint32_t GetFreeCWND() = 0;

private:

    bool InSlowStart()
    {
        if (cwnd < ssThresh)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    Timepoint lastLossTic{ 0 };// todo:
    bool InRecovery(Timepoint largestLostSentTic)
    {

        if (lastLossTic == 0 || largestLostSentTic > lastLossTic)
        {
            // a new timelost
            auto nowtic = std::chrono::steady_clock::now();
            lastLossTic = time_point_cast<std::chrono::microseconds>(nowtic).time_since_epoch().count();
        }

    }

    void ExitSlowStart()
    {
        ssThresh = cwnd;
    }


    void OnDataRecv(const AckEvent& ackEvent)
    {
        if (InSlowStart())
        {
            /// add 1 for each ack event
            cwnd += 1;
            if (cwnd >= ssThresh)
            {
                ExitSlowStart();
            }
        }
        else
        {
            /// add cwnd for each RTT
            cwndCnt++;
            cwnd += cwndCnt / cwnd;
            if (cwndCnt == cwnd)
            {
                cwndCnt = 0;
            }
        }

    }

    void OnDataLoss(const LossEvent& lossEvent)
    {
        Timepoint t;
        if (!InRecovery(t))
        {
            // Not In Recovery
            // Cut half
            cwnd = cwnd / 2;
            ssThresh = cwnd;
            // enter Recovery state
        }
        else
        {
            cwnd = cwnd - 1;
        }
    }


    uint32_t BoundCwnd(uint32_t trySetCwnd)
    {
        return std::max(minCwnd, std::min(trySetCwnd, maxCwnd));
    }

    uint32_t cwnd{ 1 };
    uint32_t cwndCnt{ 0 };

    uint32_t minCwnd{ 1 };
    uint32_t maxCwnd{ 64 };
    uint32_t ssThresh{ 32 };/** slow start threshold*/
};
