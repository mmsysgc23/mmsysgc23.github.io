// Copyright (c) 2023. ByteDance Inc. All rights reserved.

#pragma once

#include <map>
#include "basefw/base/hash.h"
#include "basefw/base/shared_ptr.h"
#include "sessionstreamcontroller.hpp"

enum MultiPathSchedulerType
{
    MULTI_PATH_SCHEDULE_NONE = 0,
    MULTI_PATH_SCHEDULE_RR = 1,
};

class MultiPathSchedulerHandler
{
public:
    virtual bool OnGetCurrPlayPos(uint64_t& currplaypos) = 0; // curr play pos
    virtual bool OnGetCurrCachePos(uint64_t& currcachepos) = 0;

    virtual bool OnGetByteRate(uint32_t& playbyterate) = 0; // bytes per second
    virtual void OnRequestDownloadSubPieces(int32_t maxsubpiececnt) = 0; // ask for more subpieces

    virtual bool DoSendDataPieceRequest(const fw::ID& sessionid, std::vector<int32_t>& datapieces) = 0;

    virtual ~MultiPathSchedulerHandler()
    {
    }
};

class MultiPathSchedulerAlgo
{
public:
    MultiPathSchedulerAlgo(const fw::ID& rid, std::map<fw::ID, fw::shared_ptr<SessionStreamController>>& dlsessionmap,
            std::multimap<int32_t, fw::shared_ptr<SessionStreamController>>& sortmmap,
            std::set<int32_t>& needdownloadpiece,
            std::set<int32_t>& needdownloadsubpiece)
            : m_rid(rid), m_sortmmap(sortmmap), m_dlsessionmap(dlsessionmap),
              m_needdownloadsubpiece(needdownloadsubpiece), m_needdownloadpiece(needdownloadpiece)
    {
    }

    virtual MultiPathSchedulerType SchedulerType()
    {
        return MultiPathSchedulerType::MULTI_PATH_SCHEDULE_NONE;
    }

    virtual int32_t StartMultiPathScheduler(fw::weak_ptr<MultiPathSchedulerHandler> mpsHandler) = 0;

    virtual bool StopMultiPathScheduler() = 0;

    virtual void OnSessionCreate(const fw::ID& sessionid) = 0;

    virtual void OnSessionDestory(const fw::ID& sessionid) = 0;

    virtual void OnResetDownload() = 0;

    virtual void DoMultiPathSchedule() = 0;

    virtual uint32_t DoSinglePathSchedule(const fw::ID& sessionid) = 0;

    virtual void OnTimedOut(const fw::ID& sessionid, std::vector<int32_t>& spns) = 0;

    virtual void OnReceiveSubpieceData(const fw::ID& sessionid, uint32_t seq, int32_t spno) = 0;

    virtual void SortSession(std::multimap<int32_t, fw::shared_ptr<SessionStreamController>>& sortmmap) = 0;

    virtual int32_t DoSendSessionSubTask(const fw::ID& sessionid) = 0;

    virtual ~MultiPathSchedulerAlgo() = default;

protected:
    fw::ID m_rid;
    std::multimap<int32_t, fw::shared_ptr<SessionStreamController>>& m_sortmmap;
    std::map<fw::ID, fw::shared_ptr<SessionStreamController>>& m_dlsessionmap;
    std::set<int32_t>& m_needdownloadsubpiece;
    std::set<int32_t>& m_needdownloadpiece;
};

