// Copyright (c) 2023. ByteDance Inc. All rights reserved.

#pragma once

#include <deque>
#include "congestioncontrol.hpp"


class SessionStreamCtlHandler
{
public:
    virtual void OnPiecePktTimeout(const basefw::ID& peerid, const std::vector<int32_t>& spns) = 0;

    virtual bool DoRequestdata(const basefw::ID& peerid, const std::vector<int32_t>& spns) = 0;
};

struct PacketSender
{
    bool CanSend(uint32_t cwnd, uint32_t downloadingPktCnt)
    {
        if (cwnd > downloadingPktCnt)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    uint32_t MaySendPktCnt(uint32_t cwnd, uint32_t downloadingPktCnt)
    {
        return cwnd - downloadingPktCnt;
    }

};

class SessionStreamController
{
public:
    typedef uint32_t SeqT;
    typedef int32_t DataPieceId;
    struct SendPacket
    {
        SeqT seq{ 0 };
        DataPieceId pieceId{ -1 };
        uint64_t sendTic{ 0 };
        uint64_t timeoutTic{ 0 };
    };

    SessionStreamController() = default;

    ~SessionStreamController()
    {
        StopSessionStreamCtl();
    }

    void StartSessionStreamCtl()
    {
    }

    void StopSessionStreamCtl()
    {
    }

    bool DoRequestdata(const basefw::ID& peerid, const std::vector<int32_t>& spns)
    {
        auto handler = ssStreamHandler.lock();
        if (handler)
        {
            return handler->DoRequestdata(peerid, spns);
        }
        return false;
    }

    void OnDataRequestPktSent(SendPacket& sendPacket)
    {
        // inform cc algo that a packet is sent
        SeqDataIdPair sentpkt;
        sentpkt.seq = sendPacket.seq;
        sentpkt.dataPieceId = sendPacket.pieceId;
        congestionCtl->OnDataSent(sentpkt);

        // add to downloading queue
    }

    void OnDataPktReceived(uint32_t seq, int32_t datapiece)
    {
        SeqDataIdPair dataPieceId;
        rttstats.UpdateRtt(0, 0, 0);
        AckEvent ackEvent;
        LossEvent lossEvent; // if we detect loss when ACK event, we may do loss check here.
        congestionCtl->OnDataAckOrLoss(ackEvent, lossEvent);
    }

    void OnLossDetectionAlarm()
    {
        DoAlarmTimeoutDetection();
    }

    void InformLossUp(LossEvent& loss)
    {
        auto handler = ssStreamHandler.lock();
        if (handler)
        {
            std::vector<int32_t> lossedPieces;
            for (auto&& piece: loss.lossPackets)
            {
                lossedPieces.emplace_back(piece.dataPieceId);
            }
            handler->OnPiecePktTimeout(sessionId, lossedPieces);
        }
    }

    void DoAlarmTimeoutDetection()
    {
        ///check timeout
        Timepoint now_t;// todo:
        AckEvent ack;
        LossEvent loss;
        lossDetect->DetectLoss(downloadingPkt, now_t, ack, -1, loss, rttstats);
        InformLossUp(loss);
    }

    uint32_t GetRtt()
    {
        return 0;
    }

    uint32_t GetInFlightPktNum()
    {
        return downloadingPkt.size();
    }

    bool CanSend()
    {
        return sendCtl->CanSend(congestionCtl->GetCWND(), GetInFlightPktNum());
    }

    uint32_t CanRequestPktCnt()
    {
        return sendCtl->MaySendPktCnt(congestionCtl->GetCWND(), GetInFlightPktNum());
    };

private:
    bool isRunning{ false };
    basefw::ID sessionId;/** The remote peer id defines the session id*/
    std::shared_ptr<CongestionCtlAlgo> congestionCtl;
    std::shared_ptr<LossDetectionAlgo> lossDetect;
    std::weak_ptr<SessionStreamCtlHandler> ssStreamHandler;
    std::deque<DownloadingPacket> downloadingPkt;

    std::unique_ptr<PacketSender> sendCtl;
    RttStats rttstats;
};

