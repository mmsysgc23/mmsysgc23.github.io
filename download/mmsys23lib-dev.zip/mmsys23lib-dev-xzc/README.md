mmsys23lib
 Contains the binary library and interface that will be released to public.
 
 