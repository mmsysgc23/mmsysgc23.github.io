Explanation of the network topology script:

# topo-1.py
Please see the parameters in the code.

# topo-2.py
Simulate TCP flows as background competing traffic.

# topo-3.py
Please see the parameters in the code.

# topo-4.py
Please see the parameters in the code.

# topo-5.py
Simulate link damage after a period of time from the start of the download.
